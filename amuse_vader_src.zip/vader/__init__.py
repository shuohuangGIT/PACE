# generated file
from .interface import Vader
