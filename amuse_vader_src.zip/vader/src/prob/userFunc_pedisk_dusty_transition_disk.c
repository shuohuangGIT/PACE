#include "userFunc.h"
#include "math.h"

#include<stdio.h>

/**************************************************************************/
/* This defines userFunc routines for a protoplanetary disk that is being */
/* photoevaporated both by X-ray radiation from the central star and FUV  */
/* radiation by stars in the environment.                                 */
/* Parameter values (and their units) include:							  */
/* dMf_inner:	Internal photoevaporation mass loss rate (g/s)			  */
/* dMf_outer: 	External photoevaporation mass loss rate (g/s)			  */
/* C0: 			Column density at edge (g/cm^2)							  */
/* Tsubl: 		Dust sublimation temperature (K)						  */
/* mmw:			Mean molecular weight (g)								  */
/* alpha:       Disk viscosity parameter                                  */
/* central_mass:Mass of central object (MSun)                             */
/* uf:          Dust fragmentation velocity (cm/s)                        */
/* rho_s:       Dust bulk density (g/cm^3)                                */
/* a0:          Dust minimum grain size (cm)                              */
/* CFL:         Error tolerance of dust solver                            */
/* err:         Error code for dust solver (0 if all is right)            */
/* dM_inner_out:Actual mass removed through IPE (g)                       */
/* dM_outer_out:Actual mass removed through EPE (g)                       */
/*                                                                        */
/* 		WARNING: PAY ATTENTION TO THE UNITS, THIS IS NOT TRIVIAL		  */
/*																		  */
/* Written by Martijn Wilhelm, 2018 									  */
/**************************************************************************/
bool isInsideArray( int A[], int n, int k ){
   for( int i = 0; i < n; i++) {
      if( A [ i ] == k ) {
         return 1;   
      }
   }
   return 0;
}

int implicit_adv_diff (const double dt, const grid *grd, 
        double *u_out, const double *u_in, const double *pebb_eff, const double *Diff, const double *v, 
        const double *g, const double *h, const double *K, const double *L,
        const double pi, const double po, const double qi, const double qo,
        const double ri, const double ro,
        gsl_vector *A, gsl_vector *B, gsl_vector *C, gsl_vector *D, 
        gsl_vector *sol){
    // Function adapted from Birnstiel 2012 model (using their delta method)

    unsigned int nr = grd->nr;
    double res, vol;

    gsl_vector_set(B, 0, qi - pi * g[0] / (h[0] * (grd->r_g[2] - grd->r_g[1])));
    gsl_vector_set(C, 0,      pi * g[1] / (h[1] * (grd->r_g[2] - grd->r_g[1])));
    gsl_vector_set(D, 0, ri);

    double D05i, D05o; 
    double h05i, h05o;

    D05i = 0.5*(Diff[0] + Diff[1]);
    h05i = 0.5*(h[0] + h[1]);

    double filter_1 = 0.;
    double filter_2 = 0.;
    for (unsigned int i=1; i < nr-1; i++) {

        filter_1 = pebb_eff[i];
        filter_2 = pebb_eff[i+1];

        D05o = 0.5*(Diff[i] + Diff[i+1]);
        h05o = 0.5*(h[i] + h[i+1]);
        vol = 0.5 * (grd->r_g[i+2] - grd->r_g[i]);

        res = h05i * D05i * g[i-1] / 
            ((grd->r_g[i+1] - grd->r_g[i]) * h[i-1]);
        if (v[i] > 0.) res += v[i]*(1.-filter_1);
        res *= -dt / vol;
        gsl_vector_set(A, i-1, res);
	
        res  = h05o * D05o * g[i] / 
            ((grd->r_g[i+2] - grd->r_g[i+1]) * h[i]);
        res += h05i * D05i * g[i] / 
            ((grd->r_g[i+1] - grd->r_g[i  ]) * h[i]);
        if (v[i+1] > 0.) res += v[i+1];
        if (v[i  ] < 0.) res -= v[i  ];
        res *= dt / vol;
        gsl_vector_set(B, i, 1. - dt*L[i] + res);

        res = -h05o * D05o * g[i+1] / 
            ((grd->r_g[i+2] - grd->r_g[i+1]) * h[i+1]);
        if (v[i+1] < 0.) res += v[i+1]*(1.-filter_2);
        res *= dt / vol;
        gsl_vector_set(C, i, res);

        //gsl_vector_set(D, i, u_in[i] + dt * K[i]);
        gsl_vector_set(D, i, u_in[i] + dt * K[i] - (
            gsl_vector_get(A, i-1)*u_in[i-1] + 
            gsl_vector_get(B, i  )*u_in[i  ] + 
            gsl_vector_get(C, i  )*u_in[i+1]));

        D05i = D05o;
        h05i = h05o;
    }

    gsl_vector_set(A, nr-2,    - po * g[nr-2] / (h[nr-2] * 
        (grd->r_g[nr] - grd->r_g[nr-1])));
    gsl_vector_set(B, nr-1, qo + po * g[nr-1] / (h[nr-1] * 
        (grd->r_g[nr] - grd->r_g[nr-1])));
    //gsl_vector_set(D, nr-1, ro);
    gsl_vector_set(D, 0, ri - 
        (gsl_vector_get(B, 0)*u_in[0] + gsl_vector_get(C, 0)*u_in[1]));
    gsl_vector_set(D, nr-1, ro - 
        (gsl_vector_get(A, nr-2)*u_in[nr-2] + gsl_vector_get(B, nr-1)*u_in[nr-1]));

    if (gsl_linalg_solve_tridiag(B, C, A, D, sol)) {
        printf("   ...error in matrix solver, exiting without convergence!\n");
        return -1;
    }

    double sol_sum = 0.;
    for (unsigned int i = 0; i < nr; i++) {
        res = gsl_vector_get(sol, i);
        sol_sum+=res;
        if (!isfinite(res)) {
            printf("   ...NaN or Inf in matrix solution (cell %i), exiting without convergence!\n", i);
            return -1;
        }
        //u_out[i] = res;//u_in[i] + res;
        u_out[i] = u_in[i] + res;
    }

    return 0;
}

double particle_size (const double dt, const double col, const double col_d,
        const double rho_s, const double alpha, const double uf, 
        const double a0, double a_prev, const double cs2, const double Vk, 
        const double gamma, const double r, const double temp, 
        const double temp_subl, bool *drift_limited){
  // compute maximum particle size in cell
  // The alpha used should be **viscous** alpha
  if (temp > temp_subl)
    return a0;

  double a_frag =  0.37 * 2. * col   * uf*uf / (alpha       * cs2 * 3.*M_PI *rho_s);
  double a_drift = 0.55 * 2. * col_d * Vk*Vk / (fabs(gamma) * cs2 * M_PI    *rho_s);
  double a_df =    0.37 * 2. * col   * uf*Vk / (fabs(gamma) * cs2 * 0.5*M_PI*rho_s);

  double a1 = a_frag;
  if (a1 > a_df)
    a1 = a_df;

  if (a1 > a_drift) {
    a1 = a_drift;
    *drift_limited = true;
  }

  if (a1 < a0)
    return a0;

  double tau = col*r/(col_d*Vk);  //the prefactor shall be updated
  double a_grow = a_prev * exp(dt/tau);
  if (a1 > a_grow)
    a1 = a_grow;

  return a1;
}

double dlnpdlnr (const unsigned int i_grad, const grid *grd, 
        const double *col, const double *pres) {
    // compute logarithmic derivative of the midplane pressure

    double gamma = grd->beta_g[i_grad+1] - 1.;
    gamma += 0.5 * grd->r_g[i_grad+1] * (pres[i_grad+1] - pres[i_grad-1]) / 
        (pres[i_grad] * (grd->r_g[i_grad+2] - grd->r_g[i_grad]));
    gamma += 0.5 * grd->r_g[i_grad+1] * (col[i_grad+1]  - col[i_grad-1] ) / 
        (col[i_grad]  * (grd->r_g[i_grad+2] - grd->r_g[i_grad]));

    return gamma;
}

double vbar_2pop (const unsigned int i, const grid *grd, const double dt, 
        const double *col, const double *r_col_d, const double *pres, 
        const double *userOut, const void *params, double *a1, double *eff_St) {
    // compute dust advection speed (due to gas entrainment and drift)

    unsigned int i_grad = i + (i == 0 ? 1 : 0) - (i == grd->nr-1 ? 1 : 0);

    double C0    = ((double *)params)[2];
    double Tsubl = ((double *)params)[3];
    double alpha = ((double *)params)[5];
    double uf    = ((double *)params)[7];
    double rho_s = ((double *)params)[8];
    double a0    = ((double *)params)[9];

    double cs2 = pres[i]/col[i];
    double Vk = grd->vphi_g[i+1];
    double gamma = dlnpdlnr(i_grad, grd, col, pres);

    double u_drift = cs2 * gamma / (2.*Vk);

    double dTdr = -alpha * ( 
        (1.-grd->beta_g[i_grad+2]) * 
            grd->r_g[i_grad+2]*grd->r_g[i_grad+2]*pres[i_grad+1] -
        (1.-grd->beta_g[i_grad  ]) * 
            grd->r_g[i_grad  ]*grd->r_g[i_grad  ]*pres[i_grad-1]) /
        (grd->r_g[i_grad+2] - grd->r_g[i_grad]);

    double u_gas = dTdr / (grd->r_g[i+1]*col[i]*Vk*(1.+grd->beta_g[i+1]));
    //double u_gas = -3. * alpha * cs2 * (1. + 7./4.) / (2. * Vk);

    bool drift_limited = false;
    a1[i] = particle_size(dt, col[i], r_col_d[i]/grd->r_g[i+1],
        rho_s, alpha, uf, a0, userOut[i + grd->nr], pres[i]/col[i], Vk, gamma, 
        grd->r_g[i+1], userOut[i + (grd->nr)*2], Tsubl, &drift_limited);

    double St0 = M_PI*0.5 * a0*rho_s/col[i];
    double St1 = M_PI*0.5 * a1[i]*rho_s/col[i];

    double fm = drift_limited ? 0.97 : 0.75;

    double p = (1. - fm)/(1. + St0*St0) + fm/(1. + St1*St1);
    double q = (1. - fm)/(1./St0 + St0) + fm/(1./St1 + St1);

    double res = p * u_gas + 2. * q * u_drift;
    
    eff_St[i] = (1. - fm)*St0 + fm * St1;

    return res;
}

// single size
double vbar (const unsigned int i, const grid *grd, const double dt, 
        const double *col, const double *r_col_d, const double *pres, 
        const double *userOut, const void *params, double *a1, double *eff_St) {
    // compute dust advection speed (due to gas entrainment and drift)

    unsigned int i_grad = i + (i == 0 ? 1 : 0) - (i == grd->nr-1 ? 1 : 0);

    double C0    = ((double *)params)[2];
    double Tsubl = ((double *)params)[3];
    double alpha = ((double *)params)[5];
    double uf    = ((double *)params)[7];
    double rho_s = ((double *)params)[8];
    double a0    = ((double *)params)[9];

    double cs2 = pres[i]/col[i];
    double Vk = grd->vphi_g[i+1];
    double gamma = dlnpdlnr(i_grad, grd, col, pres);

    double u_drift = cs2 * gamma / (2.*Vk);

    double dTdr = -alpha * ( 
        (1.-grd->beta_g[i_grad+2]) * 
            grd->r_g[i_grad+2]*grd->r_g[i_grad+2]*pres[i_grad+1] -
        (1.-grd->beta_g[i_grad  ]) * 
            grd->r_g[i_grad  ]*grd->r_g[i_grad  ]*pres[i_grad-1]) /
        (grd->r_g[i_grad+2] - grd->r_g[i_grad]);

    double u_gas = dTdr / (grd->r_g[i+1]*col[i]*Vk*(1.+grd->beta_g[i+1]));
    //double u_gas = -3. * alpha * cs2 * (1. + 7./4.) / (2. * Vk);

    double St0 = a0;

    double p = 1/(1. + St0*St0);
    double q = 1/(1./St0 + St0);

    double res = p * u_gas + 2. * q * u_drift;
    eff_St[i] = St0;

    // if (i==100){
    //     printf("%f\n", p);
    //     printf("%f\n", u_gas);
    //     printf("%f\n", q);
    //     printf("%f\n", u_drift);
    // };
    return res;
}

int dust_advance (const double t, const double dt, const grid *grd,
        double *col, double *pres, double *userOut, void *params,
        gsl_vector *A, gsl_vector *B, gsl_vector *C, gsl_vector *D, 
        gsl_vector *sol){

    int err = 0, converged;
    double errMax, errCell, gamma, t_sub = t, dt_sub = dt, tau;
    double yr = 60.*60. * 24. * 365.25;
    bool drift_limited = false;

    double C0     = ((double *)params)[2];
    double Tsubl  = ((double *)params)[3];
    double alpha  = ((double *)params)[5];
    double uf    = ((double *)params)[7];
    double rho_s = ((double *)params)[8];
    double a0    = ((double *)params)[9];
    double CFL   = ((double *)params)[10];

    double *zeros = (double*) calloc(grd->nr, sizeof(double));
    double *ones  = (double*) calloc(grd->nr, sizeof(double));
    double *u_out = (double*) calloc(grd->nr, sizeof(double));
    double *u_in  = (double*) calloc(grd->nr, sizeof(double));
    double *Diff  = (double*) calloc(grd->nr, sizeof(double));
    double *v = (double*) calloc(grd->nr, sizeof(double));
    double *h = (double*) calloc(grd->nr, sizeof(double));
    double *a1 = (double*) calloc(grd->nr, sizeof(double));
    double *eff_St = (double*) calloc(grd->nr, sizeof(double));
    double *pebb_eff = (double*) calloc(grd->nr, sizeof(double));

    // set initial quantities
    for (unsigned int i = 0; i < grd->nr; i++) {
        zeros[i] = 0.;
        ones[i]  = 1.;
        u_in[i]  = userOut[i] * grd->r_g[i+1];
        Diff[i]  = alpha * grd->r_g[i+1] * pres[i] / (grd->vphi_g[i+1]*col[i]);
        h[i] = col[i] * grd->r_g[i+1];
    }

    while (t_sub < t + dt) {
        converged = 0;

        while (!converged) {

            // get next iteration
            for (unsigned int i = 0; i < grd->nr; i++) {
                v[i] = vbar(i, grd, dt_sub, col, u_in, pres, userOut, params, a1, eff_St);
                userOut[i+3*grd->nr] = v[i];
                userOut[i+4*grd->nr] = eff_St[i];
                pebb_eff[i] = userOut[i+5*grd->nr];
            }

            if (implicit_adv_diff(dt_sub, grd, u_out, u_in, pebb_eff, Diff, v, ones, h, 
                    zeros, zeros, 1., 1., 0., 0., 0., 0., A, B, C, D, sol)) {
                err = -1;
                break;
            }

            // check for convergence
            errMax = 0.;
            for (unsigned int i = 2; i < grd->nr-1; i++) {
                errCell = fabs(u_out[i] / u_in[i] - 1.);
                if (errCell > errMax && u_out[i]/grd->r_g[i+1] >= 1e-30)
                    errMax = errCell;
            }

            if (errMax < CFL) { // if converged, accept timestep
                converged = 1;
            }
            else { // if not converged, reduce timestep
                dt_sub /= 2.;

                if (dt_sub < yr) {
                    fprintf(stderr, "Timestep too short, maximum change %e\n", 
                        errMax);
                    err = -1;
                    break;
                }
            }
        } // while not converged

        // timestep accepted
        for (unsigned int i = 0; i < grd->nr; i++) {
            userOut[i + grd->nr] = a1[i];
            u_in[i] = u_out[i];
        }

        t_sub += dt_sub;

        if (err)
            break;
    } // while end time not reached

    for (unsigned int i = 0; i < grd->nr; i++)
        userOut[i] = u_out[i] / grd->r_g[i+1];
    
    // for (unsigned int i = 0; i < grd->nr; i++)
    //     userOut[i+3*grd->nr] = v[i];

    free(ones); free(zeros); free(u_out); free(u_in); free(Diff); free(v); free(h);
    free(a1); free(eff_St); free(pebb_eff);

    return err;
}

int dust_driver (const double t, const double dt, const grid *grd,
        double *col, double *pres, double *userOut, void *params) {

    int err = 0;

    gsl_vector *A, *B, *C, *D, *sol;

    if (!(A = gsl_vector_alloc(grd->nr-1))){// Upper diagonal of tridiagonal matrix
        printf("Error: unable to allocate memory in dust evolution!");
        err = -1;
    }
    if (!(C = gsl_vector_alloc(grd->nr-1))){// Lower diagonal of tridiagonal matrix
        printf("Error: unable to allocate memory in dust evolution!");
        err = -1;
    }
    if (!(B = gsl_vector_alloc(grd->nr))){// Mid diagonal of tridiagonal matrix
        printf("Error: unable to allocate memory in dust evolution!");
        err = -1;
    }
    if (!(D = gsl_vector_alloc(grd->nr))){// RHS of matrix equation
        printf("Error: unable to allocate memory in dust evolution!");
        err = -1;
    }
    if (!(sol = gsl_vector_alloc(grd->nr))) {// Solution buffer
        printf("Error: unable to allocate memory in dust evolution!");
        err = -1;
    }

    if (!err)
        err = dust_advance(t, dt, grd, col, pres, userOut, params, A, B, C, D, sol);

    gsl_vector_free(A); gsl_vector_free(B); gsl_vector_free(C); gsl_vector_free(D);
    gsl_vector_free(sol);

    return err;
}


void
userAlpha(const double t, const double dt, const grid *grd, 
	  const double *col, const double *pres, const double *eInt,
	  const double *gamma, const double *delta,
	  void *params,
	  double *alpha) {
  fprintf(stderr, 
	  "Warning: userAlpha function called but not implemented!\n");
  return;
}

void
userEOS(const double t, const double dt, const grid *grd, 
	const double *col, const double *pres, const double *eInt,
	void *params,
	double *gamma, double *delta) {
  fprintf(stderr, 
	  "Warning: userEOS function called but not implemented!\n");
  return;
}

void
userMassSrc(const double t, const double dt, const grid *grd,
	    const double *col, const double *pres, const double *eInt,
	    const double *gamma, const double *delta,
	    void *params,
	    double *massSrc) {
  fprintf(stderr, 
	  "Warning: userMassSrc function called but not implemented!\n");
  return;
}

void
userIntEnSrc(const double t, const double dt, const grid *grd,
	     const double *col, const double *pres, const double *eInt,
	     const double *gamma, const double *delta,
	     void *params, 
	     double *intEnSrc) {
  fprintf(stderr, 
	  "Warning: userIntEnSrc function called but not implemented!\n");
  return;
}

void
userIBC(const double t, const double dt, const grid *grd,
	const double *col, const double *pres, const double *eInt,
	const double *gamma, const double *delta,
	const pres_bc_type ibc_pres, const enth_bc_type ibc_enth,
	void *params, 
	double *ibc_pres_val, double *ibc_enth_val) {
  // The alpha used here as a boundary condition should be accretion alpha
  double alpha = ((double *) params)[14];

  // printf("alpha = %f", alpha);
  double res = (1. - grd->beta_g[2])*grd->r_g[2]*grd->r_g[2]*pres[1];
  res -=       (1. - grd->beta_g[1])*grd->r_g[1]*grd->r_g[1]*pres[0];
  res *= -alpha * 2.*M_PI / ( (1. + grd->beta_h[1])*grd->vphi_h[1] );
  if (grd->linear)
    res /= grd->r_g[2] - grd->r_g[1];
  else
    res /= log(grd->r_g[2]/grd->r_g[1])*grd->r_h[1];

  if (res < 0.)
    *ibc_pres_val = res;
  else
    *ibc_pres_val = 0.;

  *ibc_enth_val = 0.;

  return;
}

void
userOBC(const double t, const double dt, const grid *grd,
	const double *col, const double *pres, const double *eInt,
	const double *gamma, const double *delta,
	const pres_bc_type obc_pres, const enth_bc_type obc_enth,
	void *params, 
	double *obc_pres_val, double *obc_enth_val) {

  fprintf(stderr, 
	  "Warning: userOBC function called but not implemented!\n");
  return;
}

void
userPreTimestep(const double t, const double dt,
		const grid *grd, double *col, double *pres,
		double *eInt, double *mBnd, double *eBnd,
		double *mSrc, double *eSrc,
		void *params, const unsigned long nUserOut,
		double *userOut) {

  fprintf(stderr, 
	  "Warning: userPreTimestep function called but not implemented!\n");
  return;
}

void
userPostTimestep(const double t, const double dt,
		 const grid *grd, double *col, double *pres,
		 double *eInt, double *mBnd, double *eBnd,
		 double *mSrc, double *eSrc,
		 void *params, const unsigned long nUserOut,
		 double *userOut) {

  double dMf_inner	= ((double *) params)[0];
  double dMf_outer	= ((double *) params)[1];
  double C0			= ((double *) params)[2];
  double T_subl     = ((double *) params)[3];
  double mmw		= ((double *) params)[4];
  double central_mass = ((double *) params)[6];
  double rho_s      = ((double *)params)[8];

  double cm_in_AU = 1.49597870691e+13; //according to amuse
  double g_in_MSun = 1.98892e+33; //according to amuse
  double s_in_yr = 31556925.993600003; //according to amuse
  double kB = 1.3806504e-16; // erg/K, according to amuse
  double G = 6.674e-8; //cm3/g/s2

  int index;
  double dSigma;

  // Birnstiel 2012 dust model evolution
  int err = dust_driver(t, dt, grd, col, pres, userOut, params);

  if (err != 0)
    fprintf(stderr, "Dust evolution did not converge!\n");

  ((double *) params)[11] = err;


  // Sublimate all dust in hot cells by transfering from dust to gas
  // Here the code uses the temperature profile
  for (unsigned int i = 0; i < grd->nr; i++) {
    index = 2*(grd->nr)+i;
    if (userOut[index] > T_subl) {
      dSigma = userOut[i] - 0.01 * C0;

      userOut[i] = 0.01 * C0;
      col[i] += dSigma;
      pres[i] += dSigma/mmw * kB*userOut[index];
    }
  }

  // Internal and external photoevaporation
  double dM_inner = dMf_inner*dt;
  double dM_outer = dMf_outer*dt;
  double dM_inner_out = 0.0;
  double dM_outer_out = 0.0;
  double dM = 0.0;
  double dM_excess = 0.0;

  double x, R, temp, lnR, logR, ln10=log(10.);
  double dM_d, v_th, Hd2, F, a_entr, f_entr;

  int edge = grd->nr-1;
  int hole = 0;
  int i, j;

  // Internal Photoevaporation
  double a = -0.5885;
  double b = 4.3130;
  double c = -12.1214;
  double d = 16.3587;
  double e = -11.4721;
  double f = 5.7248;
  double g = -2.8562;

  for (i = 0; i < grd->nr; i++) {
    x = 0.85 * (grd->r_g[i+1]/cm_in_AU) / central_mass;
    R = grd->r_g[i+1]/cm_in_AU * 0.7/central_mass;
    if (hole == 0 && x > 139.015) { hole = i; }
    if (x > 0.7 && x < 139.015) {
      lnR = log(R);  logR = log10(R);

      // Surface density profile of mass loss from Picogna 2019
      // Use radial scaling from Owen 2012
      temp = ( 6.*a*pow(lnR, 5)/(R*pow(ln10, 6)) + 5.*b*pow(lnR, 4)/(R*pow(ln10, 5)) + 4.*c*pow(lnR, 3)/(R*pow(ln10, 4)) + 3.*d*pow(lnR, 2)/(R*pow(ln10, 3)) + 2.*e*lnR/(R*pow(ln10, 2)) + f/(R*ln10) );
      temp *= pow(10., a*pow(logR, 6) + b*pow(logR, 5) + c*pow(logR, 4) + d*pow(logR, 3) + e*pow(logR, 2) + f*logR + g );
      temp *= ln10/(2.*M_PI*R);

      // Correction for radial rescaling (from change of integration variable)
      temp *= (0.7/central_mass)*(0.7/central_mass);      
      temp /= (cm_in_AU*cm_in_AU); // Unit correction      
      temp *= dM_inner; // Scale with magnitude of mass removal

      // If enough mass in bin, remove mass
      if (col[i] - temp > C0) {
        col[i] -= temp;
        dM_inner_out += temp*grd->area[i];
        // If mass to remove left from previously, try removing it
        if (dM_excess > 0.0) {
          // If enough mass in bin to compensate, remove mass
          if (col[i] - dM_excess/grd->area[i] > C0) {
            col[i] -= dM_excess/grd->area[i];
            dM_inner_out += dM_excess;
            dM_excess = 0.;
          }
          // If not enough mass in bin, remove what you can
          else {
            dM_excess -= (col[i] - C0)*grd->area[i];
            dM_inner_out += (col[i] - C0)*grd->area[i];
            col[i] = C0;
          }
        }
      }
      // If not enough mass in bin, remove what you can, save the rest
      else {
        dM_excess += (temp - (col[i] - C0))*grd->area[i];
        dM_inner_out += (col[i] - C0)*grd->area[i];
        col[i] = C0;
      }
    }//if in internal photoevaporation range
  }//for all cells

  // If not enough mass has been removed, go beyond the normal IPE region
  // This is technically the 'inner hole' regime, but the mass loss rates are
  // similar enough (Owen 2012).
  // The method used is similar to EPE, resembling inside-out clearing
  for (i = hole; dM_excess > 0. && i < grd->nr; i++) {
    dM = (col[i] - C0)*grd->area[i];
    if (dM > dM_excess) {
      col[i] -= dM_excess/grd->area[i];
      dM_inner_out += dM_excess;
      dM_excess = 0.;
    }
    else {
      col[i] = C0;
      dM_excess -= dM;
      dM_inner_out += dM;
    }
  }

  ((double *)params)[12] += dM_inner_out;

  //external photoevaporation
  for (int i = edge; (i >= 0 && dM_outer_out < dM_outer); 
		i--) {
	dM = (col[i] - C0)*grd->area[i]; // mass to be extracted

    // compute entrained fraction of dust in wind
    v_th = sqrt( (8.*kB*userOut[2*grd->nr+i])/(M_PI*mmw) );
    Hd2 = ( kB*userOut[2*grd->nr+i] * pow(grd->r_g[i+1], 3)) /
        (mmw * central_mass*g_in_MSun * G);
    F = sqrt(1./(1. + grd->r_g[i+1]*grd->r_g[i+1]/Hd2));
    a_entr = v_th * dMf_outer / (G * central_mass*g_in_MSun * 4.*M_PI * F * rho_s);
    f_entr = pow(a_entr/userOut[grd->nr+i], 0.5); // exponent 4-p, assume p=3.5

    dM_d = userOut[i]/col[i] * dM;
    if (f_entr < 1.) dM_d *= f_entr;
    //fprintf(stderr, "%i: %e %e %e %e %e %e\n", i, v_th, sqrt(Hd2), F, a_entr, f_entr, dM_d);

    if (dM > dM_outer - dM_outer_out) {
      col[i] -= (dM_outer - dM_outer_out)/grd->area[i];
      dM_outer_out = dM_outer;
    }
    else {
      col[i] -= dM/grd->area[i];
      dM_outer_out += dM;
    }

    if (dM_d > (userOut[i] - 0.01*C0)*grd->area[i])
      userOut[i] = 0.01 * C0;
    else
      userOut[i] -= dM_d/grd->area[i];
  }

  ((double *)params)[13] += dM_outer_out;

  //correct pressure
  for (i = 0; i < grd->nr; i++) {
    //T = Tm/sqrt(grd->r_g[i+1]/cm_in_AU);
    pres[i] = col[i]/mmw*kB*userOut[2*grd->nr+i];
  }

  return;
}

void
userCheckRead(
	      FILE *fp, grid *grd, const unsigned long nOut,
	      double *tOut, double *colOut,
	      double *presOut, double *eIntOut, double *mBndOut,
	      double *eBndOut, double *mSrcOut, double *eSrcOut,
	      const unsigned long nUserOut, double *userOut,
	      void *params
	      ) {
  fprintf(stderr,
	  "Warning: userCheckRead function called but not implemented!\n");
  return;
}

void
userCheckWrite(
	      FILE *fp,
	      const grid *grd, const unsigned long nOut,
	      const double *tOut, const double *colOut,
	      const double *presOut, const double *eIntOut,
	      const double *mBndOut, const double *eBndOut,
	      const double *mSrcOut, const double *eSrcOut,
	      const unsigned long nUserOut, const double *userOut,
	      const void *params
	      ) {
  fprintf(stderr,
	  "Warning: userCheckWrite function called but not implemented!\n");
  return;
}
